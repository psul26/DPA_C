// (C) COPYRIGHT 2009 Korea University C.I.S.T (Center For Information Security Technologies)
// File Name : preprocess.h
// Type : C-file
// Author : Hae-Il Jung.

// Header file

DB Preprocess(DB **Data);
