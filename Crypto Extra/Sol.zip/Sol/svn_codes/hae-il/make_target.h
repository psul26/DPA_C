// (C) COPYRIGHT 2009 Korea University C.I.S.T (Center For Information Security Technologies)
// File Name : make_target.h
// Type : C-file
// Author : Hae-Il Jung.

// Header file

UI make_target(UC* Plan, UC Target_Subkey, UI Target_Sbox, UC* Target_Bit, UI* Hw);