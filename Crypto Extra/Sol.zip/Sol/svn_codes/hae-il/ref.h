// (C) COPYRIGHT 2009 Korea University C.I.S.T (Center For Information Security Technologies)
// File Name : ref.h
// Type : C-file
// Author : Hae-Il Jung.

// Header file



#define Tr_Num 209 // Need to trace
#define Iteration 100 
#define Point 2 // Compressed points
#define Main_Point 20003 // point of wave


typedef unsigned char UC; 
typedef unsigned int UI;
typedef float DB;




