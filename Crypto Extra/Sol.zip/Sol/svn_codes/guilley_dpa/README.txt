The multi-bit DPA with a weighting based on the CPA by �ric Brier et al.
