% script launching CPA HW(L15xorL16) for the DPAcontest

cpaDESR16('.','db','HD','maxPeak',14450,14550,100,1,400,100,0);