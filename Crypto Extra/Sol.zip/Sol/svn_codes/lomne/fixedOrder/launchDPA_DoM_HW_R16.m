% script launching DPA DoM on HW(L15xorL16) for the DPAcontest

dpaDEShwR16('.','db','HD','maxPeak',1,20000,100,1,400,100);