% script launching DPA DoM on 4bits of L15xorL16 for the DPAcontest

dpaDES4bitsR16('.','db','HD','maxPeak',1,20000,100,1,400,100);