% script launching DPA DoM on 4bits of L15xorL16 for the DPAcontest following the statistically optimized order

dpaDES4bitsR16('.','stat','HD','maxPeak',14450,14550,10,1,120,100);