% script launching CPA HW(L15xorL16) with enhancement for the DPAcontest following the statistically optimized order

cpaDESR16('.','stat','HD','maxPeak',14450,14550,10,1,120,100,1);