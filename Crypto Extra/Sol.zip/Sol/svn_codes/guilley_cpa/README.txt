This is the CPA of �ric Brier et al. w/o preprocessing
