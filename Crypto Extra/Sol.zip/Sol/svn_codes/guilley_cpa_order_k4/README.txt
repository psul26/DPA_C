This is the CPA of �ric Brier et al.
with a preprocessing that consists in replacing the power traces by their fourth-order cumulant.
